# id_tb1

# TBI

## Alkitab Terjemahan Baru (Indonesian New English translation of the Bible)
